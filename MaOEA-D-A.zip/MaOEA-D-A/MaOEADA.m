classdef MaOEADA < ALGORITHM
% <multi/many> <real/integer/label/binary/permutation>
% Multiobjective evolutionary algorithm based on decomposition
% type --- 1 --- The type of aggregation function

%--------------------------------------------------------------------------

    methods
        function main(Algorithm,Problem)
            %% Parameter setting
            type = Algorithm.ParameterSet(1);

            %% Generate the weight vectors
            [W,Problem.N] = UniformlyRandomlyPoint(Problem.N,Problem.M);
            T = ceil(Problem.N/10);
            nr = ceil(Problem.N/100);
            
            %% WS - transformation
            W = 1./(W.*sum(1./W,2));
            
            %% Detect the neighbours of each solution
            B = pdist2(W,W);
            [~,B] = sort(B,2);
            B = B(:,1:T);
            theta = 0.85;

            %% Generate random population
            Population = Problem.Initialization();
            Z = min(Population.objs,[],1);
            Znad = max(Population.objs,[],1);
            EP = Population;

            %% Determine the position coordinates of each individual
            mold = sqrt(sum((Population.objs - Z).^2, 2));
            
            %% Optimization
            while Algorithm.NotTerminated(Population)
                % The number of children replacing their parents
                x=3*(Problem.FE/Problem.maxFE)-1.5;
                nr_update=ceil(nr+nr*tanh(x));
                OFF=[];

                % For each solution
                for i = 1 : Problem.N
                    % Choose the parents
                    if rand < theta
                           P = B(i,randperm(size(B,2)));
                           cond = 1;
                       
                    else
                           % R 
                           Populationobjs = Population.objs;
                           ProblemN = Problem.N;
                           R = zeros(1, ProblemN);
                           for t=1:ProblemN
                               obj_t=Population(t).obj;
                               domination = all(obj_t <= Populationobjs, 2) & any(obj_t < Populationobjs, 2);
                               domination(t) = false;
                               R(t) = sum(domination);
                           end
                    
                           % F
                           F=zeros(1, ProblemN);
                           H=diag(1.06*((ProblemN)^(-0.2))*std(Populationobjs));
                           Hn=diag(1./(1.06*((ProblemN)^(-0.2))*std(Populationobjs)));
                           detH=det(H);
                           constant=1/((((2*pi)^(Problem.M))*detH)^(1/2));
                           for p=1:ProblemN
                              x=Population(p).obj-Populationobjs;
                              xi=sum((x*Hn).*x,2)*-0.5;
                              a=sum(exp(xi));
                              f=(1/ProblemN)*constant*a;
                              F(p)=f;   
                           end
                           U=0.5*R + 0.5*F;
                           P = randperm(Problem.N);
                           [~, sorted_indices] = sort(U(P));
                           P = P(sorted_indices(1:2));
                           cond = 2;
                    end

                    % Generate an offspring
                    Offspring = OperatorGAhalf(Problem,Population(P(1:2)));

                    % Update the ideal point
                    Z = min(Z,Offspring.obj);
                    Znad = max(Znad,Offspring.obj);

                    % Update the neighbours
                    switch type
                        case 1
                            % PBI approach
                            normW   = sqrt(sum(W(P,:).^2,2));
                            normP   = sqrt(sum((Population(P).objs-repmat(Z,length(P),1)).^2,2));
                            normO   = sqrt(sum((Offspring.obj-Z).^2,2));
                            CosineP = sum((Population(P).objs-repmat(Z,length(P),1)).*W(P,:),2)./normW./normP;
                            CosineO = sum(repmat(Offspring.obj-Z,length(P),1).*W(P,:),2)./normW./normO;
                            g_old   = normP.*CosineP + 5*normP.*sqrt(1-CosineP.^2);
                            g_new   = normO.*CosineO + 5*normO.*sqrt(1-CosineO.^2);
                        case 2
                            % Tchebycheff approach
                            g_old = max(abs(Population(P).objs-repmat(Z,length(P),1)).*W(P,:),[],2);
                            g_new = max(repmat(abs(Offspring.obj-Z),length(P),1).*W(P,:),[],2);
                        case 3
                            % Tchebycheff approach with normalization
                            Zmax  = max(Population.objs,[],1);
                            g_old = max(abs(Population(P).objs-repmat(Z,length(P),1))./repmat(Zmax-Z,length(P),1).*W(P,:),[],2);
                            g_new = max(repmat(abs(Offspring.obj-Z)./(Zmax-Z),length(P),1).*W(P,:),[],2);
                        case 4
                            % Modified Tchebycheff approach
                            g_old = max(abs(Population(P).objs-repmat(Z,length(P),1))./W(P,:),[],2);
                            g_new = max(repmat(abs(Offspring.obj-Z),length(P),1)./W(P,:),[],2);
                    end
                    if cond == 1
                        Population(P(find(g_old>=g_new,nr_update))) = Offspring;
                    else
                        if nr_update <= 2
                            Population(P(find(g_old>=g_new,nr_update))) = Offspring;
                        else
                            Population(P(find(g_old>=g_new,2))) = Offspring;
                        end
                    end
                    OFF = [OFF Offspring];
                end
                % Update the new m
                mnew = sqrt(sum((Population.objs - Z).^2, 2));
                min_values = min(mold, mnew);
                max_values = max(mold, mnew);
                result = min_values >= 0.95 * max_values;
                similarity = sum(result) / Problem.N;
                mold = mnew;
                
                % Update the external population (Maintenance of the external population)
                
                
                
                EP = [EP OFF];
                EP = EP(NDSort(EP.objs,1) == 1);
                EP_value =  EP.objs;
                
                if size(EP_value,1)>2*Problem.N
                    SL=zeros(1,size(EP_value,1));
                    for i1 = 1:size(EP_value,1)
                        parallel_distance=[];
                        for i2 = 1:size(EP_value,1)
                            f_prime1 = (EP_value(i1,:) - Z) ./ (Znad - Z);
                            if i1~=i2
                                f_prime2 = (EP_value(i2,:) - Z) ./ (Znad - Z);
                                part1 = sum((f_prime1 - f_prime2).^2);
                                part2 = (sum(f_prime1 - f_prime2))^2 / Problem.M;
                                pd = sqrt(part1 - part2);
                                parallel_distance = [parallel_distance pd];
                            end
                        end
                        sort_parallel_distance = sort(parallel_distance);  
                        SL(1,i1) = prod(sort_parallel_distance(1:4));
                    end
                    [~,del_EP_individual] = sort(SL);
                    sum_del = size(EP_value,1) - 2*Problem.N;
                    EP(del_EP_individual(1:sum_del)) = [];  
                end
                
                if (Problem.FE >= 0.2 * Problem.maxFE && Problem.FE <= 0.9 * Problem.maxFE) 
                  if (mod(Problem.FE, 0.05 * Problem.maxFE) == 0) || similarity >= 0.95
                    
                    % Delete weight vectors
                    weight_subspace = zeros(1,Problem.N);
                    EP_value1 =  EP.objs;
                    for j1=1:size(EP_value1,1)
                        solutions_to_w = [];
                        for j2=1:Problem.N
                            dotProduct = dot(EP_value1(j1,:), W(j2,:));
                            norm1 = norm(W(j2,:));
                            norm2 = norm(EP_value1(j1,:));
                            cosAngle = dotProduct/(norm1 * norm2);
                            angle0 = acos(cosAngle);
                            solutions_to_w = [solutions_to_w angle0];
                        end
                        [~,shuyu] = sort(solutions_to_w);
                        weight_subspace(1,shuyu(1)) = weight_subspace(1,shuyu(1))+1;
                    end
                    
                    % Calculate score
                    [~,score_least] = sort(weight_subspace);
                    if weight_subspace(score_least(1)) ~= weight_subspace(score_least(2))
                        W(score_least(1),:)=0;
                        add_index = score_least(1);
                    else
                        convergence1 = max( (abs(Population(score_least(1)).objs- Z).*W(score_least(1),:)));
                        convergence2 = max( (abs(Population(score_least(2)).objs- Z).*W(score_least(2),:)));
                        
                        if convergence1 <= convergence2
                            W(score_least(2),:)=0;
                            add_index = score_least(2);
                        else
                            W(score_least(1),:)=0;
                            add_index = score_least(1);
                        end
                    end 
                    
                    % Add weight vectors
                    SL_AW = zeros(1,size(EP_value1,1));
                    for k1=1:size(EP_value1,1)
                        parallel_distance=[];
                        for k2=1:size(EP_value1,1)
                            f_prime1 = (EP_value1(k1,:) - Z) ./ (Znad - Z);
                            if k1 ~= k2
                                f_prime2 = (EP_value1(k2,:) - Z) ./ (Znad - Z);
                                part1 = sum((f_prime1 - f_prime2).^2);
                                part2 = (sum(f_prime1 - f_prime2))^2 / Problem.M;
                                pd = sqrt(part1 - part2);
                                parallel_distance = [parallel_distance pd];
                            end
                        end
                        sort_parallel_distance = sort(parallel_distance);
                        SL_AW(1,k1)=prod(sort_parallel_distance(1:4));
                    end
                    [~,largest_sparsity] = sort(SL_AW, 'descend');
                    xsp = EP_value1(largest_sparsity(1),:);
                    denominator = sum(1 ./ (xsp - Z));
                    wsp = 1 ./ ((xsp - Z) * denominator);
                    W(add_index,:) = wsp;
%                     Population(add_index) = EP(largest_sparsity(1));
                    
                    % Update the neighbours
                    B = pdist2(W,W);
                    [~,B] = sort(B,2);
                    B = B(:,1:T);
                    mold = sqrt(sum((Population.objs - Z).^2, 2));
                  end
                end
       
                
            end
        end
    end
end